import requests
import urllib3
import json
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
token = '2a7587d4ed38c5318cf7de93eba82957'
def submit(flag):
    header = {
        'cookie': 'ci_session_client=rdfq25htklhafl4h37a8badfejpo34q7'
    }
    data = {
        'answer': flag
    }
    req = requests.post('https://172.16.4.1/Common/sub_answer', data=data, verify=False, headers = header)
    return json.loads(req.text[1:])

if __name__ == '__main__':
    msg = submit('test')
    print(msg)
    print(msg['msg'])