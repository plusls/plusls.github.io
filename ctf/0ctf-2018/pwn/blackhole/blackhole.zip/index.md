Title: [0CTF-2018] blackhole
Tags: 0ctf-2018, ctf-pwn, pwn-stack
Date: 2018-4-2 23:16:42
Modified: 2018-4-2 23:16:42

### 分析

日哦，一看这题，64位，只有一个read有溢出，syscall禁用了一堆，只留下 open，read,，mprotect,，exit，拿头做题。（懒得放图了，没啥意思）

难道又要将mprotect的地址解析出来去调用？？？

等等，这题有libc，为啥有libc呢

开了一晚上的脑洞后，惊讶的发现了一件事情：

![alarm](img/1.png)

最后1byte为0x80时，指向的是alarm，如果是0x85就是syscall！

只需调用read，覆写alarm的got表的最后1byte为0x85，就可以通过syscall调用mprotect了！

啥，x64不会调用3个参数的函数？init函数的那几个gadget了解一下

就这样很轻易的让bss段变成可执行的了。



可是，这题没有回显，考虑使用基于时间的盲注（滚啊！这是pwn题？？？）

### exp

```python

```

### 附录

附件： [babystack.zip](babystack.zip)

